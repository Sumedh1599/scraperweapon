# ScraperWeapon

ScraperWeapon is a powerful, AI-enabled, modular web scraping library designed to overcome advanced anti-scraping defenses.

## Features

- Headless browser support
- CAPTCHA solving
- Proxy rotation
- Dynamic content handling

## Installation
